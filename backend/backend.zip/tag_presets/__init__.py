"""
Tag Presets module for LockCloud
"""
